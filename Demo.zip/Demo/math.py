def dividepi(x,y):
    return x/y

def divide(x,p):
    return x/p

def multiply(x,y):
    return x * y